### Preprocess image into a simple bitmap

import cv2
im = cv2.imread("./napis.png")